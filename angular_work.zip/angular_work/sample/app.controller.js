'use strict';
// '$location'
sampleApp.controller('sampleController',['$scope', function($scope){
		$scope.msg="From Angular controller";
		$scope.menulist = [
				{
					'name':'Home',
					'action':'home'
				},
				{
					'name':'Products',
					'action':'product'
				},
				{
					'name':'Services',
					'action':'services'
				},
				{
					'name':'Contact',
					'action':'contact'
				}				
		];
		$scope.menuclick =  function(menu_index){
			 // console.log($location.hash());
				// $scope.list_active = "active";
				console.log($scope.menulist[menu_index].action);
				//$scope.isActive($scope.menulist[menu_index].action);

		};

		// $scope.isActive = function (viewLocation) {
		// 		     var active = (viewLocation === $location.hash());
		// 		     console.log($location);
		// 		     return active;
		// };


}
]);