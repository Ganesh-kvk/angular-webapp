'use strict';
sampleApp.component('homeCompn', {
	template : '<h1>Dramatically Engage</h1>'+
                '<p>Objectively innovate empowered manufactured products whereas parallel platforms.</p>'+
                '<a href="#" class="btn btn-primary btn-lg">Engage Now</a>'
});