'use strict';
var sampleApp =  angular.module('sampleApp',['ngRoute','ui.router']);


sampleApp.run(function($state){
$state.go('main');
})