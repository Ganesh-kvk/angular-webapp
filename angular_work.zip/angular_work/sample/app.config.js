'use strict';
// $locationProvider', '$routeProvider'
sampleApp.config([ '$stateProvider', 
	function config($stateProvider){
		// $locationProvider.hashPrefix("!");
		// $routeProvider.
		// when('/', {
		// 	template : '<h1>Dramatically Engage</h1>'+
  //               '<p>Objectively innovate empowered manufactured products whereas parallel platforms.</p>'+
  //               '<a href="#" class="btn btn-primary btn-lg">Engage Now</a>'
		// }).
		// when('/#product', {
		// 	template : '<span class="glyphicon glyphicon-apple" style="font-size: 60px"></span>'+
		// 	           '<h2 class="section-heading">Completely synergize resource taxing relationships</h2>'+
  //                      '<p class="text-light">Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service.</p>'
		// }).
		// otherwise('/');
		var states = [
			{ 
			  name : 'main', 
			  url : '', 
			  template: '<h3>Its the UI-Router hello world app!</h3>'
			  // component : 'homeCompn'
		    },
			{ 
			  name : 'home', 
			  url : '/home', 
			  // template: '<h3>Its the UI-Router hello world app!</h3>'
			  component : 'homeCompn'
		    },
		    { 
			  name : 'product', 
			  url : '/product', 
			  template: '<h3>Product Page Template was called now</h3>'
		    }
		];

		// Loop over the state definitions and register them
		  states.forEach(function(state) {
		    $stateProvider.state(state);
		  });
	}
]);


// sampleApp.run(function($http, $uiRouter) {
//   window['ui-router-visualizer'].visualizer($uiRouter);
//   //$http.get('data/people.json', { cache: true });
// });

