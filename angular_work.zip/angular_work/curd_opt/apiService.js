function ping($http) {
  return function ping_to_service(url_to_call, data_to_api) {
    return $http({
		 method: 'POST',
		 url: url_to_call,
		 data : data_to_api,
		 // paramSerializer: '$httpParamSerializerJQLike'
		 // headers : {'Content-Type': 'application/x-www-form-urlencoded'}
		}).then(function successCallback(response) {
			console.log(response);
			return response;
			
		   // this callback will be called asynchronously
		   // when the response is available
		 }, function errorCallback(response) {
		   // called asynchronously if an error occurs
		   // or server returns response with an error status.
		 });
  };
}

crud_app.factory('ping', ['$http', ping()] );