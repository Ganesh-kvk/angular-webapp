callServiceApp.factory(
	'MyServiceCall', 
	// function($http, $httpParamSerializer){
		// return $http({
		// 	 method: 'POST',
		// 	 url: 'http://192.168.10.243/vamsi_th/angular_work/curd_opt/api/api.php',
		// 	 data : $httpParamSerializer({'function_to':$scope.vari}),
		// 	 // paramSerializer: '$httpParamSerializerJQLike'
		// 	 // headers : {'Content-Type': 'application/x-www-form-urlencoded'}
		// 	}).then(function successCallback(response) {
		// 		console.log(response);
		// 		// if(response.data.status === 1){
		// 		// 	$scope.usersList = response.data.result;
		// 		// 	$scope.alert_custom_type = 'success';
		// 		// }
		// 		// 	$scope.msg = response.data.mes;
		// 		// 	$scope.alert_msg = "<i>No Data Found</i>.";
				
		// 		// $scope.show_my_alert = true;
				
		// 	   // this callback will be called asynchronously
		// 	   // when the response is available
		// 	 }, function errorCallback(response) {
		// 	   // called asynchronously if an error occurs
		// 	   // or server returns response with an error status.
		// 	 });
		function($resource){
		return $resource('http://192.168.10.243/vamsi_th/angular_work/curd_opt/api/api.php', {}, {
				get : {
				// 	method :'GET',
				// 	// params : {function_to: 'apiCall'},
					isArray : true
				},
				save : {
					method : 'POST',
					// params : {function_to : 'apiCall'},
					isArray : false
				},
				// getAll :{
				// 	params : {},
				// 	headers : {
				// 		'Content-Type' : 'application/x-www-form-urlencoded;charset=utf-8'
				// 	}
				// }
		});
	  }
	// }
);