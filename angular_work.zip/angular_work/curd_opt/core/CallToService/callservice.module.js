'use strict';

var callServiceApp = angular.module('callServiceCore', ['ngResource']);

 callServiceApp.constant('domain','http://192.168.10.243/vamsi_th/angular_work/curd_opt/');
 callServiceApp.constant('api','api/api.php');
 callServiceApp.service('urls', function(domain, api){
 	this.apiUrl = domain+api;

 });

 // callServiceApp.config(['$resourceProvider', function($resourceProvider) {
 //    $resourceProvider.defaults.actions= {
 //    	getAll : {method: 'POST', isArray : false}
 //    }
 // }]);