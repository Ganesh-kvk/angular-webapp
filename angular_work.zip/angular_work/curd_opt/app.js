
crud_app.controller('crudController', 
	['$scope','$http','$location','urls','$httpParamSerializer', 'MyServiceCall', 
	function crudController($scope, $http, $location, urls, $httpParamSerializer, MyServiceCall){

		$scope.appName = 'Angular Crud Application';
		$scope.tradeMark = "&trade;";
		$scope.ServerUrl = urls.apiUrl;
		$scope.vari = 'apiCall';
		$scope.usersList = [];
		$scope.alert_msg = "<i>No Data Found</i>.";
		$scope.alert_custom_type = 'warning';
		$scope.show_my_alert = false;
		$scope.get_user_list = function(){
			$scope.usersList = MyServiceCall.get({function_to:'apiCall'});
			console.log($scope.usersList);
			
		};

		$scope.text = 'tset';
		MyServiceCall.save({},{param:$scope.text});
		
		// $scope.res_data = MyServiceCall.get({function_to: 'myCall'}, function() {});

		// $scope.get_data =  function(){

		// };
		// $scope.myHTML = 'I am an <code>HTML</code>string with ' + '<a href="#">links!</a> and other <em>stuff</em>';
		// $http({
		//  method: 'POST',
		//  url: $scope.ServerUrl,
		//  data : $httpParamSerializer({'function_to':$scope.vari}),
		//  // paramSerializer: '$httpParamSerializerJQLike'
		//  // headers : {'Content-Type': 'application/x-www-form-urlencoded'}
		// }).then(function successCallback(response) {
		// 	console.log(response);
		// 	if(response.data.status === 1){
		// 		$scope.usersList = response.data.result;
		// 		$scope.alert_custom_type = 'success';
		// 	}
		// 		$scope.msg = response.data.mes;
		// 		$scope.alert_msg = "<i>No Data Found</i>.";
			
		// 	$scope.show_my_alert = true;
			
		//    // this callback will be called asynchronously
		//    // when the response is available
		//  }, function errorCallback(response) {
		//    // called asynchronously if an error occurs
		//    // or server returns response with an error status.
		//  });
		
		$scope.edit = function(arg){
			alert(arg);
		};
		
		// $scope.alerts = [
		//     { type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' },
		//     { type: 'success', msg: 'Well done! You successfully read this important alert message.' }
		//   ];


}]
);