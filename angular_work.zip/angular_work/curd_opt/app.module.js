'use strict';
var crud_app = angular.module('crudApp',['ngSanitize', 'ngRoute', 'ui.bootstrap', 'callServiceCore']);
 
 crud_app.constant('domain','http://192.168.10.243/vamsi_th/angular_work/curd_opt/');
 crud_app.constant('api','api/api.php');
 crud_app.service('urls', function(domain, api){
 	this.apiUrl = domain+api;

 });

 // crud_app.config(['$httpProvider', function($httpProvider) {
 //    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
 // }]);
 

 // crud_app.factory('CallToService', function(){
 // 	return 'calltoservice';
 // });