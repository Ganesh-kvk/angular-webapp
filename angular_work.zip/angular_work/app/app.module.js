'use strict';
// Define the `phonecatApp` module
var PhoneCatApp = angular.module('phonecatApp', [
  // ...which depends on below modules
  'phoneList',
  'phoneDetail',
  'core',
  'ngRoute',
  'ngAnimate'
]);

PhoneCatApp.controller('phoneCatAppController', function($scope){
		$scope.cur_date = new Date();
});