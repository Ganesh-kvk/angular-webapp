'use strict';
var PhoneListModule = angular.module('phoneList',['phoneCore']);