'use strict';
PhoneListModule.component('phoneList',{

    	// template : '<ul>' +
			  //         '<li ng-repeat="phone in menuItemCtrl.phones">' +
			  //           '<span>{{phone.name}}</span>' +
			  //           '<p>{{phone.snippet}}</p>' +
			  //         '</li>' +
			  //       '</ul>'+
			  //       '<p>Total phones count {{menuItemCtrl.phones.length}}</p>',
		templateUrl : 'phone-list/phone-list.template.html',
        controllerAs: "menuItemCtrl",
    	// controller : ['$http', function phoneListController($http){
    	// 	var self = this;
    	// 	// this.phones = [
    	// 	// 	{
		   //  //       name: 'Nexus S',
		   //  //       snippet: 'Fast just got faster with Nexus S.',
		   //  //       age : 2
		   //  //     }, {
		   //  //       name: 'Motorola XOOM with Wi-Fi',
		   //  //       snippet: 'The Next, Next Generation tablet.',
		   //  //       age : 1
		   //  //     }, {
		   //  //       name: 'MOTOROLA XOOM',
		   //  //       snippet: 'The Next, Next Generation tablet.',
		   //  //       age : 3
		   //  //     }
    	// 	// ];
    	// 	// this.query = 'nexus';
    	// 	//modified to get phones list by http service
    	// 	$http.get('phone-list/phones.json').then(function(response){
    	// 		self.phones = response.data; //response.data.slice(0,4)
    	// 	});
    	// 	self.orderPop = 'name';
    	// }]

    	// using rest custom service start
    	controller : ['PhoneService',function phoneListController(PhoneService){
    		this.phones = PhoneService.query();
    		this.orderPop = 'age';

    	}]
    });

// PhoneListModule.component('greetUser', {
//     template: 'Hello, {{$ctrl.user}}!',
//     controller: function GreetUserController() {
//       this.user = 'world';
//     }
//   });