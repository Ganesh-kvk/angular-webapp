phoneDetailModule.component('phoneDetail',{
		// template:'TBD: Detail view for <span>{{phoneDetailctrl.phoneId}}</span>',
		templateUrl:'phone-detail/phonedetail.template.html',
		controllerAs : 'phoneDetailctrl',
	// 	controller : ['$http', '$routeParams', 
	// 		function phoneDetailController($http, $routeParams){
	// 		// this.phoneId = $routeParams.phoneId;
	// 		var self = this;
	// 		self.setImage = function setImage(imgurl){
	// 			self. = imgurl;
	// 		};

	// 		$http.get('json/'+$routeParams.phoneId+'.json').then(function(response){
	// 			self.phone = response.data;
	// 			self.setImage(self.phone.images[0]);
	// 		});
	// 	}
	// ]

	// Using custom resource service instead of http service
	 controller : ['$routeParams','PhoneService', function phoneDetailController($routeParams,PhoneService){
	 	var self = this;

        self.setImage = function setImage(imageUrl) {
          self.main_imgae = imageUrl;
        };

        self.phone = PhoneService.get({phoneId: $routeParams.phoneId}, function() {
          self.setImage(self.phone.images[0]);
        });
	 }]
});

