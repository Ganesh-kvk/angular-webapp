'use strict';

// Define the `core.phone` module
var phoneCoreApp = angular.module('phoneCore', ['ngResource']);