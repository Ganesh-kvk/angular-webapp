'use strict';
Customapp.component('phoneList',{

    	template : '<ul>' +
			          '<li ng-repeat="phone in menuItemCtrl.phones">' +
			            '<span>{{phone.name}}</span>' +
			            '<p>{{phone.snippet}}</p>' +
			          '</li>' +
			        '</ul>'+
			        '<p>Total phones count {{menuItemCtrl.phones.length}}</p>',
        controllerAs: "menuItemCtrl",
    	controller : function phoneListController(){
    		this.phones = [
    			{
		          name: 'Nexus S',
		          snippet: 'Fast just got faster with Nexus S.'
		        }, {
		          name: 'Motorola XOOM &trade; with Wi-Fi',
		          snippet: 'The Next, Next Generation tablet.'
		        }, {
		          name: 'MOTOROLA XOOM &trade;',
		          snippet: 'The Next, Next Generation tablet.'
		        }
    		];
    	}
    });

// Register `phoneList` component, along with its associated controller and template
// angular.
//   module('phoneCatApp').
//   component('phoneList', {
//     template:
//         '<ul>' +
//           '<li ng-repeat="phone in $ctrl.phones">' +
//             '<span>{{phone.name}}</span>' +
//             '<p>{{phone.snippet}}</p>' +
//           '</li>' +
//         '</ul>',
//     controller: function PhoneListController() {
//       this.phones = [
//         {
//           name: 'Nexus S',
//           snippet: 'Fast just got faster with Nexus S.'
//         }, {
//           name: 'Motorola XOOM™ with Wi-Fi',
//           snippet: 'The Next, Next Generation tablet.'
//         }, {
//           name: 'MOTOROLA XOOM™',
//           snippet: 'The Next, Next Generation tablet.'
//         }
//       ];
//     }
//   });

Customapp.component('greetUser', {
    template: 'Hello, {{$ctrl.user}}!',
    controller: function GreetUserController() {
      this.user = 'world';
    }
  });