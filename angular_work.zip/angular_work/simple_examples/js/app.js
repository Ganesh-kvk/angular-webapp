var Customapp = angular.module('myApp',[]);

Customapp.controller('AngAppController', function($scope){
		$scope.name = 'my name goes here default';
		$scope.subjects = [ 
		{'name' : 'English','marks' : 75},
		{'name' : 'Telugu','marks' : 80},
		{'name' : 'Maths','marks' : 90}
		];

		$scope.customer = {
		    name: 'Naomi',
		    address: '1600 Amphitheatre'
	    };
		// $scope.angversion = angular.version;
});

Customapp.controller('directiveController',function($scope){
	$scope.exampleName = "ng-show,ng-hide,ng-disabled,ng-click directives usage";
	$scope.customCounter = 0;
	// $scope.expdirectives = [
	// 		{'directiveName' : 'ng-show', 'id' : 'btnShow', 'btnName' : 'Show Button'},
	// 		{'directiveName' : 'ng-hide', 'id' : 'btnHide', 'btnName' : 'Hide Button'},
	// 		{'directiveName' : 'ng-disabled', 'id' : 'btnDisable', 'btnName' : 'Disable Button'},
	// 		{'directiveName' : 'ng-click', 'id' : 'btnClick', 'btnName' : 'Click Button'}
	// 	]


});


//Writing custom filter
// Customapp.filter('myfilter', ['$sce', function($sce){
//         return function(text) {
//             return $sce.trustAsHtml(text);
//         };
//     }]);

// angular.module('myReverseFilterApp', [])
// .filter('reverse', function() {
//   return function(input, uppercase) {
//     input = input || '';
//     var out = '';
//     for (var i = 0; i < input.length; i++) {
//       out = input.charAt(i) + out;
//     }
//     // conditional based on optional argument
//     if (uppercase) {
//       out = out.toUpperCase();
//     }
//     return out;
//   };
// })
// .controller('MyController', ['$scope', 'reverseFilter', function($scope, reverseFilter) {
//   $scope.greeting = 'hello';
//   $scope.filteredGreeting = reverseFilter($scope.greeting);
// }]);

// var PhoneListApp = angular.module('phoneCatApp',[]);
// Customapp.controller('studentContoller', ['$scope','$http', function($scope,$http){
// 	$scope.expname = "http Service usage";
// 	var url = 'data.json';
// 	$http.get(url).success(function(response){
// 		$scope.result = response;
// 	});
// }]);


Customapp.directive('userInfo', function(){
		// restrict : 'E',
		return {
	    template: 'Name: {{customer.name}} Address: {{customer.address}}'
	  };
});