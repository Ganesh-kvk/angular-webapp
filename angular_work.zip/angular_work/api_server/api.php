<?php
 // phpinfo(); exit;
$sample_list = array(
		0 => array(
				'id' => '1',
				'name' => 'vamsi',
				'email' => 'vamsi.k@ceipal.com'
			),
		1 => array(
				'id' => '2',
				'name' => 'test2',
				'email' => 'test1@gmail.com'
			),
		2 => array(
				'id' => '3',
				'name' => 'test3',
				'email' => 'test2@gmail.com'
			),
		3 => array(
				'id' => '4',
				'name' => 'test4',
				'email' => 'test4@gmail.com'
			),
		4 => array(
				'id' => '5',
				'name' => 'test5',
				'email' => 'test5@gmail.com'
			),
		5 => array(
				'id' => '6',
				'name' => 'test6',
				'email' => 'test6@gmail.com'
			)
	);	
 function apiCall(){
 	$sample_res['status'] = 1;
 	$sample_res['mes'] = "sample text goes here";
 	$sample_res['data'] = $sample_list; 
 	return json_encode($sample_res);
 }

?>